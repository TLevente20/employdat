<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/delete_confirm.css')); ?>">
    <title>Employdat</title>
</head>
<body>
    <div class="banner">
        <a href="/"><h1>Employdat</h1></a>
    </div>
    <div class="confirmation-box">
        <h2 class="warning-text">Are you sure you want to delete this record?</h2>
        <p>This action cannot be undone!</p>
        <div class="btn-container">
            <form class="opbutton" action="<?php echo e(route('remove_row',$id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-delete" type="submit">Delete</button>
            </form>
          <button class="btn btn-cancel" onclick="window.location='<?php echo e(route('home')); ?> '">Cancel</button>
        </div>
      </div>
</body>
</html><?php /**PATH C:\Users\Felhasznalo\Desktop\employdat\employdat-app\resources\views/delete_confirm.blade.php ENDPATH**/ ?>