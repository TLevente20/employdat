<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="<?php echo e(asset('css/cv_page.css')); ?>">
        <title>Employdat</title>
    </head>
    <body>
        <div class="banner">
            <a href="/"><h1>Employdat</h1></a>
        </div>
        <div>
            <button onclick="window.location='<?php echo e(route('home')); ?> '" class="btn btn-cancel">Go Back</button>
        </div>
        <div class="container">
            <h2><?php echo e($person->name); ?></h2>
            <?php if(isset($message)): ?>
                <div class="message"><?php echo e($message); ?></div>
            <?php endif; ?>
            
            <table>
                <tr>
                    <td class="input">
                        <div class="form-column">
                            <table class="output-table">
                                <tr class="border">
                            <td>Create a new CV Here:</td>
                                </tr>
                                <tr>
                            <td><form form action="<?php echo e(route('add_cv',$person->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                
                                <textarea class="text" name="textarea" id="cv" name="cv" rows="6" placeholder="Enter Cv text" required></textarea><br>
                                <button type="submit" class="btn btn-primary">Create</button>
                            </form></td>
                                </tr>
                        </table>
                        </div>
                    </td>
                    <td>
                        <div class="output-column">
                            <table class="output-table">
                                <?php if(count($person->cvs)==0): ?>
                                    <tr>
                                        <td>There is no CV to show!</td>
                                    </tr>
                                <?php else: ?>
                                    <?php if(count($person->cvs)==1): ?>
                                        <tr>
                                            <td>CV:</td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td>CVs:</td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $person->cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th >
                                            <form action="<?php echo e(route('update_cv',['id' => $person->id, 'id_cv' => $cv->id])); ?>" method="POST">
                                                <?php echo method_field('PATCH'); ?>
                                                <?php echo csrf_field(); ?>
                                                <textarea rows="4" cols="30" name="textarea" id="textarea" class="text"><?php echo e($cv->body); ?></textarea>
                                                <button type="submit" class="btn btn-primary" formaction="<?php echo e(route('update_cv', ['id' => $person->id, 'id_cv' => $cv->id])); ?>">Edit</button>
                                                <button onclick="window.location='<?php echo e(route('remove_cv', ['id' => $person->id, 'id_cv' => $cv->id])); ?>'"class="btn btn-delete" type="button">Delete</button>
                                            </form>
                                        </th>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </table>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </body>    
</html><?php /**PATH C:\Users\Felhasznalo\Desktop\employdat\employdat-app\resources\views/cv.blade.php ENDPATH**/ ?>