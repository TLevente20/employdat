<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(('css/home.css')); ?>">
    <title>Another Page</title>
</head>
<body>
    <div class="banner">
        <h1>Banner Title</h1>
    </div>
    <div class="container">
        <input type="text" placeholder="Enter something">
        <button>Button 1</button>
        <button>Button 2</button>
        <button>Button 3</button>
        <table>
            <thead>
                <tr>
                    <th>Column 1</th>
                    <th>Column 2</th>
                    <th>Column 3</th>
                    <th>Column 4</th>
                    <th>Column 5</th>
                </tr>
            </thead>
            <tbody>
                <!-- Sample table rows -->
                <tr>
                    <td>Data 1</td>
                    <td>Data 2</td>
                    <td>Data 3</td>
                    <td>Data 4</td>
                    <td>Data 5</td>
                </tr>
                <!-- Repeat this row for additional data -->
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Felhasznalo\Desktop\employdat\employdat-app\resources\views/welcome.blade.php ENDPATH**/ ?>