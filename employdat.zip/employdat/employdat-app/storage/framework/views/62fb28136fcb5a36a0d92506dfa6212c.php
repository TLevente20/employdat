<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
    <title>Employdat</title>
</head>
<body>
    <div class="banner">
        <a href="/"><h1>Employdat</h1></a>
    </div>
    
    <div class="container">
        <p>Search for a person:</p>
        <form action="<?php echo e(route('search_name')); ?>" method="GET" role="search">
            <input class="search" type="text" name="name" placeholder="Enter a name or post" id="txb">
            <button id="b1">Search</button>
        </form>
        <button onclick="window.location='<?php echo e(route('insert')); ?> '">Add new record</button>        
        <table>
            <thead>
                <tr>
                    <th class="headrow">Delete/Edit</th>
                    <th class="headrow"><a href="<?php echo e(route('home')); ?>">ID</th>
                    <th class="headrow"><a href="<?php echo e(route('order_name')); ?>">Name</th></a>
                    <th class="headrow"><a href="<?php echo e(route('order_email')); ?>">Email Address</th></a>
                    <th class="headrow"><a href="<?php echo e(route('order_post')); ?>">Post</th></a>
                    <th class="headrow">CV</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th class="buttons">
                            <form class="opbutton" action="<?php echo e(route('delete_confirm',$person->id)); ?>">
                                <button type="submit">Delete</button>
                            </form>
                            <form class="opbutton" action="<?php echo e(route('edit',$person->id)); ?>">
                                <button type="submit">Edit</button>
                            </form>
                        </th>
                        <th><?php echo e($person->id); ?></th>
                        <th><?php echo e($person->name); ?></th>
                        <th><?php echo e($person->email); ?></th>
                        <th><?php echo e($person->post); ?></th>
                        <th>
                            <?php if(count($person->cvs)==0): ?>
                            <a class="underline" href="<?php echo e(route('cvs', $person->id)); ?>"><?php echo e('No CV found! Add here -->'); ?></a>
                            <?php elseif((count($person->cvs)==1)): ?>
                            <a class="underline" href="<?php echo e(route('cvs', $person->id)); ?>"><?php echo e('Go to CV -->'); ?></a>
                            <?php else: ?>
                            <a class="underline" href="<?php echo e(route('cvs', $person->id)); ?>"><?php echo e('Go to CVs ('.count($person->cvs).') -->'); ?></a>
                            <?php endif; ?>
                        </th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
            </tbody>
        </table>
    </div><div class="paginate">
    <?php echo e($people->links()); ?>

</div>
</body>

</html>
<?php /**PATH C:\Users\takac\Desktop\employdat\employdat-app\resources\views/home.blade.php ENDPATH**/ ?>